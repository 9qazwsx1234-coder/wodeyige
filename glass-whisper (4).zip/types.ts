
export enum Sender {
  User = 'User',
  Char = 'Char',
}

export enum Mode {
  Online = 'Online',
  Offline = 'Offline',
}

export interface Sticker {
  id: string;
  name: string;
  url: string;
  allowAI: boolean; // Controls if AI can use this sticker
}

export interface OfflinePreset {
  id: string;
  name: string;
  content: string;
  enabled: boolean;
}

export interface OfflineConfig {
  bannedWords: string;
  minWords: number;
  maxWords: number;
  presets: OfflinePreset[];
}

export interface OnlinePreset {
  id: string;
  name: string;
  content: string;
  enabled: boolean;
}

export interface OnlineConfig {
  presets: OnlinePreset[];
}

export interface QuoteInfo {
  id: string;
  content: string;
  senderName: string;
}

export interface Message {
  id: string;
  sender: Sender;
  content: string; // Text or Sticker URL or Voice Text
  type: 'text' | 'sticker' | 'voice';
  timestamp: number;
  thinkingTime?: number; // In seconds
  wordCount?: number;
  isThinking?: boolean;
  isRecalled?: boolean;
  quote?: QuoteInfo;
}

export interface CustomImages {
  headerBg?: string;
  footerBg?: string;
  // Icons
  settingsIcon?: string;
  onlinePresetIcon?: string;
  offlinePresetIcon?: string; // ᗜ𖥦ᗜ
  uiConfigIcon?: string;      // ᗜ_ᗜ
  
  sendIcon?: string;
  waitIcon?: string;
  moreIcon?: string;
  
  // More Menu Icons
  voiceIcon?: string;
  stickerIcon?: string;
  switchIcon?: string;
}

export interface AppSettings {
  // Appearance
  fontSize: number; // Bubble font size
  globalFontSize: number; // Global body font size
  globalFontColor: string; // Global text color override
  bubbleScale: number;
  fontUrl: string;
  darkMode: boolean;
  backgroundImage: string;
  showNames: boolean; // Toggle for showing names next to avatar
  
  // Custom UI
  customImages: CustomImages;

  // Features
  realTimeEnabled: boolean;
  
  // Personas
  userName: string;
  userAvatar: string;
  userDesc: string;
  userBubbleStyle: string; // CSS Code
  
  charName: string;
  charAvatar: string;
  charDesc: string;
  charBubbleStyle: string; // CSS Code
  
  // World & Logic
  worldBook: string;
  bannedWords: string; // Global banned words
  
  // API
  proxyUrl: string;
  apiKey: string;
  model: string;
}
